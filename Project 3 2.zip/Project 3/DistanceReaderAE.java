import java.io.FileNotFoundException;
import java.util.List;

public class DistanceReaderAE implements DistanceReaderInterface {
    @Override
    public List<RoadInterface> loadRoads(String filename) throws FileNotFoundException {
        throw new UnsupportedOperationException("Unimplemented method 'loadRoads'");
    }

    @Override
    public List<String> loadCities(String filename) throws FileNotFoundException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'loadCities'");
    }
    
}
