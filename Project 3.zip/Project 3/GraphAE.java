import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.PriorityQueue;

public class GraphAE<NodeType, EdgeType extends Number> 
extends BaseGraph<NodeType,EdgeType>
implements GraphADT<NodeType, EdgeType>{
      /**
     * While searching for the shortest path between two nodes, a SearchNode
     * contains data about one specific path between the start node and another
     * node in the graph.  The final node in this path is stored in it's node
     * field.  The total cost of this path is stored in its cost field.  And the
     * predecessor SearchNode within this path is referened by the predecessor
     * field (this field is null within the SearchNode containing the starting
     * node in it's node field).
     *
     * SearchNodes are Comparable and are sorted by cost so that the lowest cost
     * SearchNode has the highest priority within a java.util.PriorityQueue.
     */
    protected class SearchNode implements Comparable<SearchNode> {
        public Node node;
        public double cost;
        public SearchNode predecessor;
        public SearchNode(Node node, double cost, SearchNode predecessor) {
            this.node = node;
            this.cost = cost;
            this.predecessor = predecessor;
        }
        public int compareTo(SearchNode other) {
            if( cost > other.cost ) return +1;
            if( cost < other.cost ) return -1;
            return 0;
        }
    }

      /**
     * This helper method creates a network of SearchNodes while computing the
     * shortest path between the provided start and end locations.  The
     * SearchNode that is returned by this method is represents the end of the
     * shortest path that is found: it's cost is the cost of that shortest path,
     * and the nodes linked together through predecessor references represent
     * all of the nodes along that shortest path (ordered from end to start).
     *
     * @param start the data item in the starting node for the path
     * @param end the data item in the destination node for the path
     * @return SearchNode for the final end node within the shortest path
     * @throws NoSuchElementException when no path from start to end is found
     *         or when either start or end data do not correspond to a graph node
     */
    protected SearchNode computeShortestPath(NodeType start, NodeType end) {
        Hashtable<NodeType,SearchNode> visited= null;
        
        if(!nodes.containsKey(start) || !nodes.containsKey(end)){
            throw new NoSuchElementException("Invalid data entry found, No such value exsists");
            //Code throws an error if the data isn't found
       }
            visited = new Hashtable<>();//Notes down all the visited nodes
       //creating a minimum priority queue for the nodes transversing from the starter node
       PriorityQueue<SearchNode> pq = new PriorityQueue<>();
       SearchNode path = new SearchNode(nodes.get(start),0.0,null);
       pq.add(path);
       SearchNode sn = null; 
       while(!pq.isEmpty()){
            sn = pq.remove(); //the current search node which has the minimum edge node
            if(!visited.containsKey(sn.node.data)){
                //adding the node to the hashtable with the visited nodes
                visited.put(sn.node.data,sn);

                //using dijkstra implementation to add the nodes to the queue 
                for(Edge edge : sn.node.edgesLeaving){
                    if(!visited.containsKey(edge.successor)) {
                    SearchNode next = new SearchNode(edge.successor,sn.cost + edge.data.doubleValue(),sn);
                    pq.add(next);
                    }
                }
            }
       }
       //Code throws "no such element" exception if the node can't be reached 
       if (visited.containsKey(end) == false) throw new 
            NoSuchElementException("The exact end node isn't reachable in the graph");
    
    return visited.get(end);
    
        
    }

    /**
     * Returns the list of data values from nodes along the shortest path
     * from the node with the provided start value through the node with the
     * provided end value.  This list of data values starts with the start
     * value, ends with the end value, and contains intermediary values in the
     * order they are encountered while traversing this shorteset path.  This
     * method uses Dijkstra's shortest path algorithm to find this solution.
     *
     * @param start the data item in the starting node for the path
     * @param end the data item in the destination node for the path
     * @return list of data item from node along this shortest path
     */
    public List<NodeType> shortestPathData(NodeType start, NodeType end) {
        SearchNode path = computeShortestPath(start,end); //call the helper method
        List<NodeType> pD = new LinkedList<>();
        
        while(!path.node.data.equals(start)){
           //traversing from end to start and adding them to the linked list 
            pD.add(path.node.data);
            path = path.predecessor;
        }
        pD.add(start);
        
        //Reversing the linked list
        List<NodeType> straightWalk = new LinkedList<>();
        for(int i = pD.size()-1; i >=0; i--){
            straightWalk.add(pD.get(i));
        }
        return straightWalk;
    }

     /**
     * Returns the cost of the path (sum over edge weights) of the shortest
     * path from the node containing the start data to the node containing the
     * end data.  This method uses Dijkstra's shortest path algorithm to find
     * this solution.
     *
     * @param start the data item in the starting node for the path
     * @param end the data item in the destination node for the path
     * @return the cost of the shortest path between these nodes
     */
    public double shortestPathCost(NodeType start, NodeType end) {
        //Call the shortest path function to get the path and the returning cost
        SearchNode pathS = computeShortestPath(start,end);
        return pathS.cost;
 
    }




    
    
}
