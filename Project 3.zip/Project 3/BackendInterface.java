import java.util.List;

public interface BackendInterface{
	
	// public BackendInterface(GraphADT<NodeType,EdgeType>);

	public List<RoadInterface> loadRoads(String filename);

 	public int CityAECount(CityAE node);

	public int edgeCount(RoadAE edge);

	public List<CityAE> getShortestPath(CityAE start,RoadAE end);

	public List<CityAE> getPathCost(CityAE start,RoadAE end);

	public RoadAE getDistance(CityAE start, RoadAE end);

	public void addCityAE(CityAE CityAE);

	public void removeCityAE(CityAE CityAE);

	public boolean checkCityAE(CityAE CityAE);

	public boolean checkEdge(CityAE edge);
	
	}
