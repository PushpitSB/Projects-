public class RoadAE implements RoadInterface{

    @Override
    public String getOriginCity() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getOriginCity'");
    }

    @Override
    public String getDestinationCity() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getDestinationCity'");
    }

    @Override
    public int getDistance() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getDistance'");
    }

    
}