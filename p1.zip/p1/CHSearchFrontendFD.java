
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class CHSearchFrontendFD implements CHSearchFrontendInterface {
    Scanner userInput;
    CHSearchBackendInterface backend;

    public CHSearchFrontendFD(Scanner userInput, CHSearchBackendInterface backend){
        this.userInput = userInput;
        this.backend = backend;
    }
    public void runCommandLoop(){
       
        char I = mainMenuPrompt();

        if(I!='Q'){
            
             List<String> val = chooseSearchWordsPrompt();
             if(I == 'L'){
                System.out.println("Loading Data");
                try {
                    String file = userInput.next();
                    backend.loadData(file);
                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                runCommandLoop();
             }
             else if(I == 'T'){
                System.out.println("searching for title words");
                backend.findPostsByTitleWords(userInput.next()); 
                runCommandLoop();
             }
             else if(I == 'B'){
                System.out.println("seaching for body");
                backend.findPostsByBodyWords(userInput.next());
                runCommandLoop();
             }
             else if(I == 'P'){
                System.out.println("checking for posts");
                searchPostCommand(val);
                runCommandLoop();
             }
             else if(I =='S'){
                System.out.println("printing stats");
                displayStatsCommand();
                runCommandLoop();
             }

        }
        System.out.println("thanks for using the program");
        return;

    }
    public char mainMenuPrompt(){
                char I;
                System.out.println("Type in any charachter with in the menu to go to that menu, type Q to quit");
                System.out.println("[L]oad data from file");
                System.out.println("Search Post [T]itles");
                System.out.println("Search Post [B]odies");
                System.out.println("Search [P]ost titles and bodies");
                System.out.println("Display [S]tatistics for dataset");
                System.out.println("[Q]uit");
               
                I = userInput.next().charAt(0);
                
                if(I=='L'||I == 'T'|| I== 'B'|| I== 'P' || I == 'S' || I == 'Q') return I;
                return '\0';
    }
    public void loadDataCommand(){
        try{
        backend.loadData("");
        }
        catch(Exception e){
            e.printStackTrace();
        }



     }
    public List<String> chooseSearchWordsPrompt(){
        List<String> prompts = new ArrayList<>();
        System.out.println("Enter the search terms");
        while(userInput.hasNext()){
            prompts.add(userInput.nextLine());
        }
        return prompts;
    }

    public void displayStatsCommand(){
        System.out.println(backend.getStatisticsString());

    }
    @Override
    public void searchTitleCommand(List<String> words) {
        String word = "";
            for(int i= 0; i < words.size(); i++){
                word = word + " "+ words.get(i);
            }
            List<String> tit = backend.findPostsByTitleWords(word);

            for(int i =0; i < tit.size(); i++){
                System.out.println(tit.get(i));
            }
        
    }

    @Override
    public void searchBodyCommand(List<String> words) {
        String word = "";
            for(int i= 0; i < words.size(); i++){
                word = word + " "+ words.get(i);
            }
            List<String> tit = backend.findPostsByBodyWords(word);

            for(int i =0; i < tit.size(); i++){
                System.out.println(tit.get(i));
            }
        
    }

    @Override
    public void searchPostCommand(List<String> words) {
        String word = "";
        for(int i= 0; i < words.size(); i++){
            word = word + " "+ words.get(i);
        }
        List<String> tit = backend.findPostsByTitleOrBodyWords(word);

        for(int i =0; i < tit.size(); i++){
            System.out.println(tit.get(i));
        }
        
    }

}
