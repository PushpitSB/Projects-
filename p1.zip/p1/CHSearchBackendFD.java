import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class CHSearchBackendFD implements CHSearchBackendInterface {
    HashtableWithDuplicateKeysInterface<String,PostInterface> hashtable;
    PostReaderInterface postReader;
    public CHSearchBackendFD(HashtableWithDuplicateKeysInterface<String,PostInterface> hashtable, PostReaderInterface postReader)
    {
        this.hashtable =  hashtable;
        this.postReader =  postReader;

    }
    public void loadData(String filename) throws FileNotFoundException{
        
    }
    public List<String> findPostsByTitleWords(String words){
       
         List<String> posts =  new ArrayList<>();
        //creates a new list
        posts.add("pizza");
        posts.add("burger");
        posts.add("spinach");
        posts.add("peanut butter sandwich");
        posts.add("subway");
        return posts;
    }
    public List<String> findPostsByBodyWords(String words){
        List<String> posts =  new ArrayList<>();
        //creates a new list
        posts.add("pizza");
        posts.add("burger");
        posts.add("spinach");
        posts.add("peanut butter sandwich");
        posts.add("subway");
        return posts;
    }
    public List<String> findPostsByTitleOrBodyWords(String words){
        List<String> posts =  new ArrayList<>();
        //creates a new list
        posts.add("pizza");
        posts.add("burger");
        posts.add("spinach");
        posts.add("peanut butter sandwich");
        posts.add("subway");
        return posts;
    }
    @Override
    public String getStatisticsString() {
        // TODO Auto-generated method stub
        return null;
    }
}

