import java.util.List;
import java.util.Scanner;

public class FrontendDeveloper_Tests {
    /**
     * check for the prompt and if the menu is printed correctly 
     * @return true if the menu is correct false otherwise
     */
public static boolean test1() { /* test code here */ 
    //instance of TextUITester class to test
    TextUITester test1 = new TextUITester("T\ndata");
  //creating a front end interface
    CHSearchFrontendFD chSF = new CHSearchFrontendFD(new Scanner(System.in), new CHSearchBackendFD(null, null));
    chSF.runCommandLoop();
    String answer = test1.checkOutput();
     String checker = "Type in any charachter with in the menu to go to that menu, type Q to quit\n" + "[L]oad data from file\n" 
    + "Search Post [T]itles\n" + "Search Post [B]odies\n" + "Search [P]ost titles and bodies\n" + "Display [S]tatistics for dataset\n"
    + "[Q]uit\n" + "thanks for using the program\n"; 
    
    if(answer.equals(checker)) return true;
    return false;
}
/**
 * testers for chooseSearchWordsPrompt()
 * @return true if the words are loaded are correctly
 */
public static boolean test2() { 
    //instance of TextUITester class to test
    TextUITester test = new TextUITester("hello" + "\n" + "1" + "true");
      //creating a front end interface
    CHSearchFrontendFD chSF = new CHSearchFrontendFD(new Scanner(System.in), new CHSearchBackendFD(null, null));

    List<String> ws = chSF.chooseSearchWordsPrompt();
    String answer = test.checkOutput();
   /*for(int i =0; i < ws.size();i++){
        System.out.println(ws.get(i));
    }
    System.out.println(answer);*/
    //checking if the values are correct
    if(!ws.get(0).equals("hello")) return false;
    if(!ws.get(1).equals("1true")) return false;
    return true;    

 }

/**
 * tester for search Title command and chooseSearchWordsPrompt();
 * @return true, if the prompt is right false otherwise
 */
public static boolean test3() {
    //instance of TextUITester class to test
    TextUITester test = new TextUITester("hello" + "\n" + "1" + "true");
   //creating a front end interface
    CHSearchFrontendFD chSF = new CHSearchFrontendFD(new Scanner(System.in), new CHSearchBackendFD(null, null));
    List<String> rand = chSF.chooseSearchWordsPrompt();
    chSF.searchTitleCommand(rand); //using search title command to get title
    String answer = test.checkOutput();
    //correct string    
    String correct = "Enter the search terms\n" + "pizza\n" + "burger\n" + "spinach\n" + "peanut butter sandwich\n" + "subway\n";
    if(answer.equals(correct)) return true;
    return false;    
 }
/**
 * tests searchBodyCommand(List<String> words)
 * @return true if Body Command works correctly false otherwise
 */
public static boolean test4() { 
    //instance of TextUITester class to test
    TextUITester test = new TextUITester("hello" + "\n" + "1" + "true");
     //creating a front end interface
    CHSearchFrontendFD chSF = new CHSearchFrontendFD(new Scanner(System.in), new CHSearchBackendFD(null, null));
    List<String> rand = chSF.chooseSearchWordsPrompt();
    chSF.searchBodyCommand(rand);
    String answer = test.checkOutput();
    String correct = "Enter the search terms\n" + "pizza\n" + "burger\n" + "spinach\n" + "peanut butter sandwich\n" + "subway\n";
    if(answer.equals(correct)) return true;
    return false;    
}
/**
 * tests searchPostCommand(List<String> words)
 * @return true if correct out put is printed false otherwise
 */
public static boolean test5() { 
    //instance of TextUITester class to test
    TextUITester test = new TextUITester("hello" + "\n" + "1" + "true");
     //creating a front end interface
    CHSearchFrontendFD chSF = new CHSearchFrontendFD(new Scanner(System.in), new CHSearchBackendFD(null, null));
    List<String> rand = chSF.chooseSearchWordsPrompt();
    chSF.searchPostCommand(rand);
    String answer = test.checkOutput();
    String correct = "Enter the search terms\n" + "pizza\n" + "burger\n" + "spinach\n" + "peanut butter sandwich\n" + "subway\n";
    if(answer.equals(correct)) return true;
    return false; 
}
public static boolean integrationTest6(){
    TextUITester testIntegrate6 = new TextUITester("L\ndata/fake.txt\nB\nstevia\nQ");
    		// Use data wrangler's code to load post data
	PostReaderInterface postLoader = new PostReaderDW();
		// Use algorithm engineer's code to store and search for data
	HashtableWithDuplicateKeysInterface<String, PostInterface> hashtable;
		hashtable = new HashtableWithDuplicateKeysAE<>();
		// Use the backend developer's code to manage all app specific processing
	CHSearchBackendInterface backend = new CHSearchBackendBD(hashtable, postLoader);
		// Use the frontend developer's code to drive the text-base user interface
	Scanner scanner = new Scanner(System.in);
	CHSearchFrontendInterface frontend = new CHSearchFrontendFD(scanner, backend);
	frontend.runCommandLoop();
    String output = testIntegrate6.checkOutput();
    System.out.println(output);

    return false;
}

public static void main(String[] args) {
    System.out.println(test1() + " test1()");
    System.out.println(test2() + " test2()");
    System.out.println(test3() + " test3()");
    System.out.println(test4() + " test4()");
    System.out.println(test5() + " test5()");
   // System.out.println(integrationTest6() + " test6()");
   

    
}
}
