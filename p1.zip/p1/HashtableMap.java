// --== CS400 Project One File Header ==--
// Name: Pushpit Singh
// CSL Username: pushpit
// Email: psingh76@wisc.edu
// Lecture #: 003, 1:20 ; Florian; MWF
// Notes to Grader: <any optional extra notes to your grader>
import java.security.Key;
import java.util.NoSuchElementException;

/**
 * hashtable map class that implements the hashtable using an array with generic 
 * data types
 */
public class HashtableMap<KeyType,ValueType> implements MapADT<KeyType,ValueType> {
    class  Value<KeyType,ValueType> {
        KeyType key;
        ValueType value;
        public Value(){
            this.key = null;
            this.value = null;
        }
        public Value(KeyType key, ValueType value) {
            this.key = key;
            this.value = value;
        }
        public void setKey(KeyType key){
            this.key=  key;
        }
        public void setValue(ValueType val){
            this.value = val;
        }
        public KeyType getKey(){
            return key;
        }
        public ValueType getValue(){
            return value;
            }
        
    
        }
    protected Value[] hashTable;//creating an array to stores key value pairs
    private Value<KeyType,ValueType> removed = new Value<>(null,null); //if the element from the hashTabel is deleted
    private int capacity; //the capacity variable
    private int number = 0;//shows the number of contents in the hash table
    /**
     * constructor to initialize user put capacity
     * @param capacity - the capacity of the array
     */
    public HashtableMap(int capacity){ //contructor to initialize capacity
        hashTable = (Value<KeyType,ValueType>[])new Value[capacity];
        this.capacity = capacity; 
    }
    /**
     * default contructor to initiazlie
     */
    public HashtableMap(){
        hashTable = (Value<KeyType,ValueType>[])new Value[8];
        capacity = 8; //default capacity
    }
    //to calculate index value = maths.abs(key.hashCode())%capacity


    
    /**
     * calculator for load factor
     * @return loadFactor;
     * 
     */
    private double loadFacCalc(){
        //return the loadfactor
        return ((double)number)/capacity;
    }
    
    /**
     * index calculator for rehashing and if the index is greater than the capacity
     * @param index - the index calculated through hashcode method
     * @return - the index to insert
     */
    private int index2(int index){
        //if index is greater than capcacity 
        if(index>=capacity){
            index = index%capacity; 
            index = index2(index);

        }
        //if its at null then return index
        
        if(hashTable[index]==null) return index;
        //if the index is occupied by element with same hashcode element
        else if(hashTable[index]!=null ){
            index++;
            if(index==capacity)index=0;
            index = index2(index++);
         }
         
         return index;
        
    }



    /**
     *    // add a new key-value pair/mapping to this collection
    // throws exception when key is null or duplicate of one already stored
    * @@param - key - the key value
    * @@param - value - the value 
     */
    @Override
    public void put(KeyType key, ValueType value) throws IllegalArgumentException {
        if(key == null || this.containsKey(key)) throw new IllegalArgumentException("the key is either null or already exsists"); 
        //calculating the value of the undex by given formula
        int index = Math.abs(key.hashCode())%capacity; //caculating the index from the key Value pair for the first time

        //removing thre markers of removed variables
        Value<KeyType,ValueType> obj1 = new Value<>(key,value);
        
       // System.out.println(hashTable[2].getValue());}
        
        index = index2(index);

        
        hashTable[index] = obj1;
        number++;
        

        //if loadfactor greater than 0.7 then rehash
        if(loadFacCalc()>=0.7){
            //doubling the size of the array

            Value<KeyType,ValueType>[] temp = new Value[capacity];
            //storing and removing value from the hashtable
            for(int i =0; i < capacity;i++){
                if(hashTable[i]==null||hashTable[i]==removed)continue;
                temp[i] = hashTable[i];
                
                remove((KeyType)hashTable[i].getKey());
            }
            number =0;
            capacity = capacity*2;
            hashTable = new  Value[capacity];
            //rehashing 
            for(int i = 0; i < temp.length;i++){
                if(temp[i]==null||temp[i]==removed)continue;
                put((KeyType)temp[i].getKey(),(ValueType)temp[i].getValue());
            }
        } //then checking if index out of capacity rehashing it

        
    }
    /**
     * check whether a key maps to a value within this collection
     * @return true, if the value contains key , false, if there is no element
     * 
     */
    @Override   
    public boolean containsKey(KeyType key) {
        //checking if the array has the element with the same key
        for(int i = 0; i <  capacity;i++){
            if(hashTable[i]==removed||hashTable[i]==null)continue;
            if(hashTable[i].getKey().equals(key)){
                return true;
            }
        }

        return false;
    }
    /**
     * removed elemnt index calc 
     * ives the next not removed element
     * @param i - index
     * @return - index
     */
    private int removed(int i){
        if(hashTable[i] == null) throw new NoSuchElementException("No such key exsists");
        if(hashTable[i]==removed){
            removed(i+1);}
        return i;
    }                   

    /**
     *  retrieve the specific value that a key maps to
     * @throws exception when key is not stored in this collection
     */
     @Override
     public ValueType get(Object key) throws NoSuchElementException {
        int index =0;
        for(int i =0; i < capacity; i++){
            if(hashTable[i]== null || hashTable[i].getKey() == null)continue;
            if(hashTable[i].getKey().equals(key)) index =i;

        }
        
 
        if(hashTable[index] ==null){
            throw new NoSuchElementException("the key does not exsist");
        }
        if(hashTable[index].getKey() == null){
            index = removed(index+1);
            return (ValueType)hashTable[index].getValue();
        }
        if(hashTable[index].getKey().equals(key)){
            return (ValueType)hashTable[index].getValue();
        }
        throw new NoSuchElementException("the key does not exsist");
        /* 
        
       
         if(key == null) throw new NoSuchElementException("Key cannot be null");
         for(int i = 0; i <  capacity;i++){
              
             System.out.println(hashTable[i]);
             System.out.println(hashTable[i].getValue());
             System.out.println(hashTable[i].getKey());
             
             if(hashTable[i].getKey().equals(key)){
              return (ValueType)hashTable[i].getValue();
             
         }
         }
         //else throw an error
         throw new NoSuchElementException("No such key exsists");*/
     }
    /**
     *  remove the mapping for a given key from this collection
     * throws exception when key is not stored in this collection
     * @param - key keyvalue
     * @return - ValueType - the value of element removed
     */
    @Override
    public ValueType remove(KeyType key) throws NoSuchElementException {
        Value removedObj = null; //storing the value of the removed object
        if(!containsKey((key))) throw new NoSuchElementException("the key does not exsist");
        for(int i = 0; i <  capacity;i++){
            if(hashTable[i]==removed)continue;
            if(hashTable[i]!=null && hashTable[i].getKey().equals(key)){
                removedObj = hashTable[i];
                hashTable[i] = removed;
                number--;
                break;
                
            }
        }
        //if key not found throw an error
        
        //else return the removed value

        return (ValueType)removedObj.getValue();
    }
    /**
     * remove all key-value pairs from this collection
     * 
     */
    @Override
    public void clear() {
        //clearing all the value
        for(int i = 0; i <  capacity;i++){
            hashTable[i] = null;
        }
        number = 0;
        
        
    }
    /**
     * return the size
     */
    @Override
    public int getSize() {

        return number;
    }
    /**
     * returns the capacirty
     */
    @Override
    public int getCapacity() {
        return capacity;
    }

}
