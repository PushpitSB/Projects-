public class RadixSorter {


     void radixSort(int array[]) {
    int maxVal =getMax(array); 
    for (int number = 1; maxVal / number > 0; number *= 10) {
        int[] bucket = new int[10]; //the buckets
        for (int i = 0; i < array.length; i++) {
            int indexB = (array[i] / number) % 10; //calculating bucket index
            bucket[indexB]++;
        }
        for (int i = 1; i < bucket.length; i++) {
            bucket[i] += bucket[i - 1];
        }
        int[] sortedArray = new int[array.length];
        for (int i = array.length - 1; i >= 0; i--) {
            int bucketIndex = (array[i] / number) % 10;
            sortedArray[bucket[bucketIndex] - 1] = array[i];
            bucket[bucketIndex]--;
        }
        for (int i = 0; i < array.length; i++) {
            array[i] = sortedArray[i];
        }
    }
  }

        

        /**
         * Does counting sort on the given array for the given digit.
         * digit is 10^(digit to sort by)
        **/
        void countingSort(int array[], int digit) {
                // Array to temporarily store sorted array
                int output[] = new int[array.length];
                // Stores how many elements we have of each digit
                int count[] = new int[10];

                // Count how many elements we have of each digit
                for (int num : array) {
                        count[(num / digit) % 10]++;
                }

                // Count how many elements we have of each digit less than or equal to itself
                for (int i = 1; i < 10; i++) {
                        count[i] += count[i - 1];
                }

                // Sort the array by digit
                for (int i = array.length - 1; i >= 0; i--) {
                        int num = (array[i] / digit) % 10;
                        output[count[num] - 1] = array[i];
                        count[num]--;
                }

                // Copy output array into original array
                for (int i = 0; i < array.length; i++) {
                        array[i] = output[i];
                }
        }

        /**
         * Get the maximal element of a given array
        **/
        int getMax(int array[]) {
                int max = array[0];
                for (int num : array) {
                        max = num > max ? num : max;
                }
                return max;
        }

        public static void main(String[] args) {
                System.out.println("This is RadixSorter");
        }
}

